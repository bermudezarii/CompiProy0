#include <stdio.h>
#include <stdlib.h>

int main()
{
/*    int c;
    FILE *file;
    printf("Ruta del archivo:\n");
    char NombreArchivo[50];
    gets(NombreArchivo);
    file = fopen(NombreArchivo, "r");
    if (file) {
        while ((c = getc(file)) != EOF)
            putchar(c);
        fclose(file);
    }else{
    printf("No se pudo leer el nombre del archivo.");
    }

    printf("Hello world!\n");
*/
    printf("al menos pasa por main");
    system_goal();
    return 0;
}
