#ifndef GLOBAL_H_INCLUDED
#define GLOBAL_H_INCLUDED

extern token scanner(void);
extern char token_buffer[6];
extern int paradae;
#endif // GLOBAL_H_INCLUDED



