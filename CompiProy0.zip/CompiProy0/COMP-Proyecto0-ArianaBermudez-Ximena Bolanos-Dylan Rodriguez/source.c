/*
FIGURE 2.1 SCANNER LOOP TO RECOGNIZE IDENTIFIER AND INTEGER
LITERALS
*/


#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

typedef enum token_types
{
	BEGIN, END, READ, WRITE, ID, INTLITERAL,
	LPAREN, RPAREN, SEMICOLON, COMMA, ASSIGNOP,
	PLUSOP, MINUSOP, SCANEOF
} token;



/*
FIGURE 2.3 COMPLETE SCANNER FUNCTION FOR MICRO
*/

/* character classification macros */


token current_token = ID;
char token_buffer[6];
int i=0;

void lexical_error(int in_char){
    printf("Se ha producido un error, %d",in_char);

}
void buffer_char(int c){
    token_buffer[i]=toupper(c);
    i=i+1;
}
void clear_buffer(){
    i=0;
    memset(&token_buffer[0], 0, sizeof(token_buffer));
}
token check_reserved(){
 if(token_buffer[0]=='B'&&token_buffer[1]=='E'&&token_buffer[2]=='G'&&token_buffer[2]=='I'&&token_buffer[3]=='N'){
  return BEGIN;
 }else{
      if(token_buffer[0]=='W'&&token_buffer[1]=='R'&&token_buffer[2]=='I'&&token_buffer[3]=='T'&&token_buffer[4]=='E'){
           return WRITE;
      }else{
      if(token_buffer[0]=='E'&&token_buffer[1]=='N'&&token_buffer[2]=='D'){
      return END;
      }else{
            return READ;
      }
    }
  }

 }




token scanner(void){
	int in_char, c;

	clear_buffer();
	if(feof(stdin))
		return SCANEOF;
	while ((in_char = getchar()) != EOF){
		if (isspace(in_char))
			continue; /*do nothing*/
		else if (isalpha(in_char)){
			/* code to recognize identifieres goes here */
			/*
			* ID ::= LETTER | ID LETTER
			*				| ID DIGIT
			*				| ID UNDERSCORE
			*/


			buffer_char(in_char);
			for (c = getchar(); isalnum(c) || c == '_'; c = getchar())
				buffer_char(c);
			ungetc(c, stdin);
			return check_reserved();
		}
		else if (isdigit(in_char)){
			/* code to recgonize int literals goes here */
			/*
			* INTLITERAL ::= DIGIT |
			*				 INTLITERAL DIGIT
			*/

			buffer_char(in_char);
			for (c = getchar(); isdigit(c); c = getchar())
				buffer_char(c);
			ungetc(c, stdin);
			return INTLITERAL;
		}

		else if (in_char == '(')
			return LPAREN;
		else if (in_char == ')')
			return RPAREN;
		else if (in_char == ';')
			return SEMICOLON;
		else if (in_char == ',')
			return COMMA;
		else if (in_char == '+')
			return PLUSOP;
		else if (in_char == ':'){
			/* LOOKING FOR ":="*/
			c = getchar();
			if (c == '=')
				return ASSIGNOP;
			else {
				ungetc(c, stdin);
				lexical_error(in_char);
			}
		}
		else if(in_char == '-'){
			/*looking for --,comment start*/
			c = getchar();
			if (c == '-'){
				while ((in_char = getchar()) != '\n');
			}
			else{
				ungetc(c,stdin);
				return MINUSOP;
			}
		}
		else
			lexical_error(in_char);
	}
}

token next_token(void){
    return scanner();
}

void syntax_error(token comparar){
    //char snum[5];
    //itoa(comparar, snum, 10);
    printf("Error, no se encontro la palabra esperada :v");
}

/*
* es una funcion que muestra si hubo palabras que no concordaron con lo solicitado en el parser
*/
void match(token comparar){
    token siguiente = next_token();
     if (comparar != siguiente){
        syntax_error(comparar);
     }
}





/*METERLO EN OTRO DOC EN VEZ DE DESCARGARLO*/



/*
THE PARSER IS STARTED BY CALLING THE PROCEDURE CORRESPONDINGO TO SYSTEM GOAL
*/



void system_goal(void){
	/* <system goal> ::= <program> SCANEOF */
	printf("System goal");
	program();
	match(SCANEOF);
}



/*-*/

void program(void){
	/* <program> ::= BEGIN <statement list> END*/
	match(BEGIN);
	statement_list();
	match(END);
}


/*
THE STATEMENT LIST, ES A LO QUE SUENA XD, EL NEXT_TOKEN TOMA EL DE LA MAS IZQUIERDA
*/

//VERSION 1

void statement_list(void){
	/*
	* <statement list> ::= <statement> { <statement> }
	*/

	statement();
	while (1) {
		switch (next_token()){
		case ID:
		case READ:
		case WRITE:
			statement();
			break;
		default:
			return;
		}
	}
}

/*-*/

void statement(void){
	token tok = next_token();

	switch (tok){
		case ID:
		/* <STATEMENT> ::= ID := <expression> ; */
		match(ID); match(ASSIGNOP);
		expression(); match(SEMICOLON);
		break;

		case READ:
		/* <statement> ::= READ ( <id list> ) ; */
		match(READ); match(LPAREN);
		id_list(); match(RPAREN);
		match(SEMICOLON);
		break;

		case WRITE:
		/* <statement> ::= WRITE ( <expr list> ) ; */
		match(WRITE); match(LPAREN);
		expr_list(); match(RPAREN);
		match(SEMICOLON);
		break;

	default:
		syntax_error(tok);
		break;
	}
}




void id_list(void){
	/* <id list> ::= ID { , ID } */
	match(ID);

	while(next_token() == COMMA){
		match(COMMA);
		match(ID);
	}
}





void expression(void){
	token t;

	/*
	* <expression> ::= <primary> {<add op> <primary>}
	*/

	primary();
	for(t = next_token(); t== PLUSOP || t == MINUSOP; t = next_token()){
		add_op();
		primary();
	}
}





void expr_list(void){
	/* <expr list> ::= <expression> { , <expression> }*/

	expression();

	while(next_token() == COMMA){
		match(COMMA);
		expression();
	}
}






void add_op(void){
	token tok = next_token();

	/* <addop> ::= PLUSOP | MINUSOP*/
	if (tok == PLUSOP | MINUSOP)
		match(tok);
	else
		syntax_error(tok);
}



void primary(void){
	token tok = next_token();

	switch(tok){
		case LPAREN:
		/* <primary> ::= (<expression>)*/
		match(LPAREN), expression();
		match(RPAREN);
		break;

		case ID:
		/*<primary> ::= ID*/
		match(ID);
		break;

		case INTLITERAL:
		/*<primary> ::= INTLITERAL*/
		match(INTLITERAL);
		break;

	default:
		syntax_error(tok);
		break;
	}
}
