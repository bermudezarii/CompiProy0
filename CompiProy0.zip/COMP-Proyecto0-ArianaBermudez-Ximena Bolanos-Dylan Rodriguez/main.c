#include <stdio.h>
#include <stdlib.h>

int parada;
int main()
{
    int c;
    FILE *file;
    printf("Ruta del archivo:\n");
    char NombreArchivo[50];
    gets(NombreArchivo);
    file = fopen(NombreArchivo, "r");

    if (file) {
        while (parada==0)
            scanner(file);
        fclose(file);

    }else{
    printf("No se pudo leer el nombre del archivo.");
    }


    return 0;
}
